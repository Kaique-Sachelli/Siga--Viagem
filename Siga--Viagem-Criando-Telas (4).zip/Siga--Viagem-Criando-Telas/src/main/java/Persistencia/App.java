package java;
/*
import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;
import javax.swing.JOptionPane;

public class App {

     public static void main(String[] args) {
         int op;
         var menu = "1-Cadastrar\n2-Remover\n3-Atualizar\n4-Listar\n0-Sair";
         do{
             op = parseInt(showInputDialog(menu));
             switch(op){
                 case 1:{
                     var nome = showInputDialog("Nome?");
                     var fone = showInputDialog("Fone?");
                     var email = showInputDialog("E-mail?");
                     var p = new Pessoa(nome, fone, email);
                     var dao = new PessoaDAO();
                     try{
                         dao.cadastrar(p);
                         showMessageDialog(null, "Cadastrou!");
                     }
                     catch(Exception e){
                         e.printStackTrace();
                         showMessageDialog(null, "Tente depois");
                     }
                     break;
                 }
                 case 0:
                     showMessageDialog(null, "Até mais");
                     break;
             }
         }while(op != 0);
     }
 }
*/